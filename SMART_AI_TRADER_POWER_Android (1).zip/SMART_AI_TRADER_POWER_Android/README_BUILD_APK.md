# SMART AI TRADER POWER — Android APK Build Guide

## Why APK Compilation Requires Android Studio / Android SDK
This workspace runs inside a Node.js web runtime where Android SDK (`sdkmanager`), Gradle, and JDK are not installed. Therefore, the complete Kotlin + Jetpack Compose project is packaged here so you can compile a signed, installable `.apk` cleanly on your machine or CI runner.

## Steps to Build Installable APK
1. Extract `SMART_AI_TRADER_POWER_Android.zip`.
2. Open the extracted folder in **Android Studio Ladybug (2024.2+)** with **JDK 17** and **Android SDK Platform 35**.
3. Let Gradle sync all dependencies (Compose BOM, Room DB, OkHttp, Coroutines).
4. Connect your Android phone (USB Debugging enabled) or run from terminal:
   ```bash
   ./gradlew assembleDebug
   ```
   Output APK path:
   `app/build/outputs/apk/debug/app-debug.apk`
5. For Release APK:
   ```bash
   ./gradlew assembleRelease
   ```

## Floating Overlay Over Quotex Setup
1. Install and launch **SMART AI TRADER POWER** on Android 8.0+.
2. Tap **START FLOATING**.
3. Grant **Display over other apps** (`SYSTEM_ALERT_WINDOW`) when prompted.
4. Open the **Quotex** Android app — the draggable AI emblem floats on the side of your screen.
5. Tap the floating AI emblem to expand/collapse the **Floating Signal Board** and press **ANALYZE NOW**.

## Quotex OTC Data Policy
Quotex does not provide a public official REST/WebSocket API for proprietary OTC pairs.
- Without an authorized Quotex OTC Bridge URL configured, OTC pairs display **DATA UNAVAILABLE**.
- Public Spot Exchange pairs (`BTCUSDT-SPOT`, `ETHUSDT-SPOT`, etc.) stream live verified exchange candles and are explicitly labeled **Not Quotex OTC**.
