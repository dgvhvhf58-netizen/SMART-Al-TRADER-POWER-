# SMART AI TRADER POWER ProGuard Rules
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-keep class com.smartaitrader.power.data.model.** { *; }
-keep class com.smartaitrader.power.data.local.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
