package com.smartaitrader.power.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.smartaitrader.power.data.local.SignalDatabase
import com.smartaitrader.power.data.local.SignalHistoryEntity
import com.smartaitrader.power.data.model.Candle
import com.smartaitrader.power.data.model.MarketFeedResult
import com.smartaitrader.power.data.model.SignalDirection
import com.smartaitrader.power.data.model.SignalEvaluation
import com.smartaitrader.power.data.model.Timeframe
import com.smartaitrader.power.data.remote.QuotexMarketRepository
import com.smartaitrader.power.domain.engine.SignalEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

data class VerifiedAccuracyStats(
    val wins: Int = 0,
    val losses: Int = 0,
    val pending: Int = 0,
    val noTrade: Int = 0,
    val verifiedTotal: Int = 0,
    val summaryText: String = "Accuracy Pending (0/10 verified)"
)

data class DashboardUiState(
    val selectedAssetId: String = "BTCUSDT-SPOT",
    val selectedTimeframe: Timeframe = Timeframe.M1,
    val bridgeUrl: String = "",
    val isLoading: Boolean = false,
    val candles: List<Candle> = emptyList(),
    val sourceLabel: String = "Connecting authorized market feed...",
    val unavailableReason: String? = null,
    val evaluation: SignalEvaluation? = null
)

class DashboardViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = QuotexMarketRepository()
    private val dao = SignalDatabase.getInstance(application).signalDao()

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState

    val history = dao.observeAllSignals()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Single source of truth for Signal History & Accuracy Dashboard
    val verifiedStats: StateFlow<VerifiedAccuracyStats> = history.map { items ->
        val wins = items.count { it.result == "WIN" }
        val losses = items.count { it.result == "LOSS" }
        val pending = items.count { it.result == "PENDING" }
        val noTrade = items.count { it.result == "NO_TRADE" }
        val verifiedTotal = wins + losses
        val summary = if (verifiedTotal < 10) {
            "Accuracy Pending ($verifiedTotal/10 verified)"
        } else {
            val pct = (wins * 100.0) / verifiedTotal
            String.format("%.1f%% (%d/%d)", pct, wins, verifiedTotal)
        }
        VerifiedAccuracyStats(wins, losses, pending, noTrade, verifiedTotal, summary)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), VerifiedAccuracyStats())

    init {
        analyzeNow(persistRecord = false)
    }

    fun selectAsset(assetId: String) {
        _uiState.value = _uiState.value.copy(selectedAssetId = assetId, candles = emptyList(), unavailableReason = null)
        analyzeNow(persistRecord = false)
    }

    fun selectTimeframe(tf: Timeframe) {
        _uiState.value = _uiState.value.copy(selectedTimeframe = tf, candles = emptyList())
        analyzeNow(persistRecord = false)
    }

    fun updateBridgeUrl(url: String) {
        _uiState.value = _uiState.value.copy(bridgeUrl = url)
    }

    fun clearHistory() {
        viewModelScope.launch { dao.clearAll() }
    }

    fun analyzeNow(persistRecord: Boolean = true) {
        val state = _uiState.value
        viewModelScope.launch {
            _uiState.value = state.copy(isLoading = true)
            when (val res = repository.fetchCandles(state.selectedAssetId, state.selectedTimeframe, state.bridgeUrl)) {
                is MarketFeedResult.Unavailable -> {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        candles = emptyList(),
                        sourceLabel = "DATA UNAVAILABLE",
                        unavailableReason = res.reason,
                        evaluation = null
                    )
                }
                is MarketFeedResult.Available -> {
                    val eval = SignalEngine.evaluate(res.candles, res.assetId, state.selectedTimeframe)
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        candles = res.candles,
                        sourceLabel = "${res.sourceName} · ${res.freshnessStatus}",
                        unavailableReason = null,
                        evaluation = eval
                    )
                    resolveExpiredPending(res.assetId, state.selectedTimeframe, res.candles)
                    if (persistRecord && eval.direction != SignalDirection.DATA_UNAVAILABLE && eval.entryPrice != null) {
                        val isDir = eval.direction == SignalDirection.UP || eval.direction == SignalDirection.DOWN
                        dao.insertSignal(
                            SignalHistoryEntity(
                                id = UUID.randomUUID().toString(),
                                timestamp = eval.evaluatedAt,
                                expiryTimestamp = eval.evaluatedAt + state.selectedTimeframe.durationMs,
                                assetId = eval.assetId,
                                marketSource = res.sourceName,
                                timeframe = state.selectedTimeframe.label,
                                direction = eval.direction.displayLabel,
                                confidence = eval.confidence,
                                riskLevel = eval.riskLevel.name,
                                entryPrice = eval.entryPrice,
                                exitPrice = null,
                                result = if (isDir) "PENDING" else "NO_TRADE",
                                reasonsSummary = eval.reasons.joinToString(" | ")
                            )
                        )
                    }
                }
            }
        }
    }

    private suspend fun resolveExpiredPending(assetId: String, tf: Timeframe, candles: List<Candle>) {
        if (candles.isEmpty()) return
        val pending = dao.getPendingForAsset(assetId, tf.label)
        val now = System.currentTimeMillis()
        for (rec in pending) {
            if (now < rec.expiryTimestamp) continue
            val expiryCandle = candles.firstOrNull {
                val closeTime = it.time + tf.durationMs
                closeTime >= rec.expiryTimestamp && now >= closeTime
            } ?: candles.lastOrNull()?.takeIf { it.time >= rec.expiryTimestamp } ?: continue
            val won = if (rec.direction == SignalDirection.UP.displayLabel) {
                expiryCandle.close > rec.entryPrice
            } else {
                expiryCandle.close < rec.entryPrice
            }
            dao.resolveSignal(rec.id, expiryCandle.close, if (won) "WIN" else "LOSS")
        }
    }
}
