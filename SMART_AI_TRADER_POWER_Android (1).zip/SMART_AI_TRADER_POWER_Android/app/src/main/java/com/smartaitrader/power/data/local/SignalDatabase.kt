package com.smartaitrader.power.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "signal_history")
data class SignalHistoryEntity(
    @PrimaryKey val id: String,
    val timestamp: Long,
    val expiryTimestamp: Long,
    val assetId: String,
    val marketSource: String,
    val timeframe: String,
    val direction: String,
    val confidence: Int,
    val riskLevel: String,
    val entryPrice: Double,
    val exitPrice: Double?,
    val result: String, // WIN, LOSS, PENDING, NO_TRADE
    val reasonsSummary: String
)

@Dao
interface SignalHistoryDao {
    @Query("SELECT * FROM signal_history ORDER BY timestamp DESC")
    fun observeAllSignals(): Flow<List<SignalHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSignal(entity: SignalHistoryEntity)

    @Query("SELECT * FROM signal_history WHERE result = 'PENDING' AND assetId = :assetId AND timeframe = :timeframe")
    suspend fun getPendingForAsset(assetId: String, timeframe: String): List<SignalHistoryEntity>

    @Query("UPDATE signal_history SET exitPrice = :exitPrice, result = :result WHERE id = :id")
    suspend fun resolveSignal(id: String, exitPrice: Double, result: String)

    @Query("DELETE FROM signal_history")
    suspend fun clearAll()
}

@Database(entities = [SignalHistoryEntity::class], version = 1, exportSchema = false)
abstract class SignalDatabase : RoomDatabase() {
    abstract fun signalDao(): SignalHistoryDao

    companion object {
        @Volatile
        private var INSTANCE: SignalDatabase? = null

        fun getInstance(context: Context): SignalDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    SignalDatabase::class.java,
                    "smart_ai_trader_power.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
