package com.smartaitrader.power.domain.engine

import com.smartaitrader.power.data.model.Candle
import com.smartaitrader.power.data.model.FactorResult
import com.smartaitrader.power.data.model.RiskLevel
import com.smartaitrader.power.data.model.SignalDirection
import com.smartaitrader.power.data.model.SignalEvaluation
import com.smartaitrader.power.data.model.Timeframe
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object SignalEngine {
    private const val EPS = 1e-9

    fun evaluate(candles: List<Candle>, assetId: String, timeframe: Timeframe): SignalEvaluation {
        if (candles.size < 35) {
            return SignalEvaluation(
                assetId = assetId,
                timeframe = timeframe,
                direction = if (candles.isEmpty()) SignalDirection.DATA_UNAVAILABLE else SignalDirection.NO_TRADE,
                confidence = 0,
                riskLevel = RiskLevel.EXTREME,
                entryPrice = candles.lastOrNull()?.close,
                buyerPressurePct = 50,
                sellerPressurePct = 50,
                rsi14 = null,
                ema20 = null,
                ema50 = null,
                ema200 = null,
                atr14 = null,
                marketStructure = "INSUFFICIENT DATA",
                trendDirection = "UNKNOWN",
                reasons = listOf("Minimum 35 verified candles required for 18-factor evaluation."),
                factors = emptyList()
            )
        }

        val closes = candles.map { it.close }
        val lastIdx = candles.lastIndex
        val c0 = candles[lastIdx]
        val c1 = candles[lastIdx - 1]

        val ema20 = computeEma(closes, 20)
        val ema50 = computeEma(closes, 50)
        val ema200 = computeEma(closes, 200)
        val rsi = computeWilderRsi(closes, 14)
        val (macdLine, macdSig, macdHist) = computeMacd(closes)
        val atr = computeAtr(candles, 14)

        val factors = mutableListOf<FactorResult>()
        val range0 = max(c0.high - c0.low, EPS)
        val body0 = abs(c0.close - c0.open)
        val upperWick0 = c0.high - max(c0.open, c0.close)
        val lowerWick0 = min(c0.open, c0.close) - c0.low
        val isBull0 = c0.close > c0.open
        val isBear0 = c0.close < c0.open

        // 1. Candlestick Pattern
        val (patName, patWeight) = when {
            isBull0 && c1.close < c1.open && c0.close >= c1.open && c0.open <= c1.close && body0 > abs(c1.close - c1.open) ->
                "Bullish Engulfing" to 8
            isBear0 && c1.close > c1.open && c0.open >= c1.close && c0.close <= c1.open && body0 > abs(c1.close - c1.open) ->
                "Bearish Engulfing" to -8
            lowerWick0 >= body0 * 2.0 && upperWick0 <= body0 * 0.6 ->
                "Hammer Pin Bar" to 7
            upperWick0 >= body0 * 2.0 && lowerWick0 <= body0 * 0.6 ->
                "Shooting Star Rejection" to -7
            else -> (if (isBull0) "Bullish Bar" else "Bearish Bar") to (if (body0 / range0 > 0.6) (if (isBull0) 5 else -5) else 0)
        }
        factors += FactorResult(1, "Candlestick Pattern", patName, biasLabel(patWeight), patWeight, "Latest bar pattern: $patName")

        // 2. Candle Strength
        val strengthPct = ((body0 / range0) * 100).roundToInt()
        val strengthW = if (strengthPct >= 58) (if (isBull0) 6 else -6) else 0
        factors += FactorResult(2, "Candle Strength", "$strengthPct%", biasLabel(strengthW), strengthW, "Body-to-range ratio")

        // 3 & 4. Buyer & Seller Pressure
        val pressureBars = candles.takeLast(5)
        var buySum = 0.0
        var weightSum = 0.0
        for (bar in pressureBars) {
            val w = max(bar.volume, 1.0)
            buySum += ((bar.close - bar.low) / max(bar.high - bar.low, EPS)) * w
            weightSum += w
        }
        val buyerPct = ((buySum / max(weightSum, EPS)) * 100).roundToInt()
        val sellerPct = 100 - buyerPct
        val buyW = if (buyerPct >= 65) 7 else if (buyerPct >= 58) 4 else 0
        val sellW = if (sellerPct >= 65) -7 else if (sellerPct >= 58) -4 else 0
        factors += FactorResult(3, "Buyer Pressure", "$buyerPct%", biasLabel(buyW), buyW, "5-bar buyer close control")
        factors += FactorResult(4, "Seller Pressure", "$sellerPct%", biasLabel(sellW), sellW, "5-bar seller rejection control")

        // 5. Volume Analysis
        val avgVol = candles.dropLast(1).takeLast(20).map { it.volume }.average()
        val rvol = if (avgVol > 0 && c0.volume > 0) c0.volume / avgVol else 1.0
        val volW = if (avgVol > 0 && rvol >= 1.2) (if (isBull0) 6 else -6) else 0
        factors += FactorResult(5, "Volume Analysis", String.format("%.2fx", rvol), biasLabel(volW), volW, "Relative volume vs 20-SMA")

        // 6. RSI (14)
        val curRsi = rsi[lastIdx]
        val rsiW = when {
            curRsi == null -> 0
            curRsi <= 32.0 -> 7
            curRsi >= 68.0 -> -7
            curRsi > 53.0 -> 4
            curRsi < 47.0 -> -4
            else -> 0
        }
        factors += FactorResult(6, "RSI (14)", curRsi?.let { String.format("%.1f", it) } ?: "N/A", biasLabel(rsiW), rsiW, "Wilder RSI(14)")

        // 7. MACD (12,26,9)
        val curMacd = macdLine[lastIdx]
        val curSig = macdSig[lastIdx]
        val curHist = macdHist[lastIdx]
        val macdW = if (curMacd != null && curSig != null && curHist != null) {
            if (curMacd > curSig && curHist > 0) 6 else if (curMacd < curSig && curHist < 0) -6 else 0
        } else 0
        factors += FactorResult(7, "MACD", curHist?.let { String.format("%.5f", it) } ?: "N/A", biasLabel(macdW), macdW, "MACD histogram momentum")

        // 8, 9, 10. EMA 20 / 50 / 200
        val e20 = ema20[lastIdx]
        val e50 = ema50[lastIdx]
        val e200 = ema200[lastIdx]
        val e20W = e20?.let { if (c0.close > it) 6 else -6 } ?: 0
        val e50W = e50?.let { if (c0.close > it) 6 else -6 } ?: 0
        val e200W = e200?.let { if (c0.close > it) 5 else -5 } ?: 0
        factors += FactorResult(8, "EMA 20", e20?.let { String.format("%.5f", it) } ?: "N/A", biasLabel(e20W), e20W, "Short-term EMA")
        factors += FactorResult(9, "EMA 50", e50?.let { String.format("%.5f", it) } ?: "Pending", biasLabel(e50W), e50W, "Medium-term EMA")
        factors += FactorResult(10, "EMA 200", e200?.let { String.format("%.5f", it) } ?: "Pending", biasLabel(e200W), e200W, "Macro EMA 200")

        // 11. ATR (14)
        val curAtr = atr[lastIdx]
        factors += FactorResult(11, "ATR (14)", curAtr?.let { String.format("%.5f", it) } ?: "N/A", "NEUTRAL", 0, "Volatility gauge")

        // 12-18. Structure, S/R, Trend, Breakout, Fakeout, Momentum, Volatility
        val recentSlice = candles.dropLast(1).takeLast(20)
        val priorHigh = recentSlice.maxOf { it.high }
        val priorLow = recentSlice.minOf { it.low }
        val breakoutW = when {
            c0.close > priorHigh && body0 / range0 >= 0.5 -> 7
            c0.close < priorLow && body0 / range0 >= 0.5 -> -7
            else -> 0
        }
        val fakeoutW = when {
            c0.high > priorHigh && c0.close < priorHigh && upperWick0 >= range0 * 0.4 -> -7
            c0.low < priorLow && c0.close > priorLow && lowerWick0 >= range0 * 0.4 -> 7
            else -> 0
        }
        val trendScore = e20W + e50W + e200W
        val trendDir = if (trendScore >= 10) "STRONG UPTREND" else if (trendScore <= -10) "STRONG DOWNTREND" else "SIDEWAYS / MIXED"
        val trendW = if (trendScore >= 10) 6 else if (trendScore <= -10) -6 else 0

        val roc5 = ((c0.close - candles[lastIdx - 5].close) / max(candles[lastIdx - 5].close, EPS)) * 100
        val momW = if (roc5 > 0 && (curHist ?: 0.0) > 0) 5 else if (roc5 < 0 && (curHist ?: 0.0) < 0) -5 else 0

        factors += FactorResult(12, "Market Structure", trendDir, biasLabel(trendW), trendW, "Swing sequence")
        factors += FactorResult(13, "Support & Resistance", "S:${String.format("%.4f", priorLow)} R:${String.format("%.4f", priorHigh)}", "NEUTRAL", 0, "20-bar S/R bounds")
        factors += FactorResult(14, "Trend Direction", trendDir, biasLabel(trendW), trendW, "Composite EMA trend")
        factors += FactorResult(15, "Breakout", if (breakoutW != 0) "Active" else "None", biasLabel(breakoutW), breakoutW, "20-bar breakout check")
        factors += FactorResult(16, "Fakeout", if (fakeoutW != 0) "Rejection Trap" else "None", biasLabel(fakeoutW), fakeoutW, "Wick liquidity sweep")
        factors += FactorResult(17, "Market Momentum", String.format("%+.3f%%", roc5), biasLabel(momW), momW, "5-bar ROC + MACD")

        val validAtrs = atr.filterNotNull()
        val meanAtr = if (validAtrs.isNotEmpty()) validAtrs.takeLast(30).average() else range0
        val volRatio = (curAtr ?: range0) / max(meanAtr, EPS)
        val riskLevel = when {
            volRatio > 2.2 -> RiskLevel.EXTREME
            volRatio > 1.7 || volRatio < 0.6 -> RiskLevel.HIGH
            else -> RiskLevel.MODERATE
        }
        factors += FactorResult(18, "Market Volatility", String.format("%.2fx ATR", volRatio), "NEUTRAL", 0, "Volatility regime")

        val bullScore = factors.filter { it.weight > 0 }.sumOf { it.weight }
        val bearScore = factors.filter { it.weight < 0 }.sumOf { abs(it.weight) }
        val total = bullScore + bearScore
        val dominance = if (total > 0) max(bullScore, bearScore).toDouble() / total else 0.5
        val net = bullScore - bearScore

        val direction = when {
            riskLevel == RiskLevel.EXTREME -> SignalDirection.NO_TRADE
            dominance < 0.67 || abs(net) < 18 -> SignalDirection.NO_TRADE
            net > 0 -> SignalDirection.UP
            else -> SignalDirection.DOWN
        }

        val confidence = min(96, max(20, (dominance * 75 + min(abs(net), 45) * 0.55).roundToInt()))
        val reasons = factors.filter { abs(it.weight) >= 5 }.take(4).map { "${it.name}: ${it.valueText}" }

        return SignalEvaluation(
            assetId = assetId,
            timeframe = timeframe,
            direction = direction,
            confidence = if (direction == SignalDirection.NO_TRADE) min(confidence, 54) else confidence,
            riskLevel = if (direction != SignalDirection.NO_TRADE && dominance >= 0.78) RiskLevel.LOW else riskLevel,
            entryPrice = c0.close,
            buyerPressurePct = buyerPct,
            sellerPressurePct = sellerPct,
            rsi14 = curRsi,
            ema20 = e20,
            ema50 = e50,
            ema200 = e200,
            atr14 = curAtr,
            marketStructure = trendDir,
            trendDirection = trendDir,
            reasons = reasons.ifEmpty { listOf("Insufficient multi-factor alignment — NO TRADE") },
            factors = factors
        )
    }

    private fun biasLabel(weight: Int) = when {
        weight > 0 -> "BULLISH"
        weight < 0 -> "BEARISH"
        else -> "NEUTRAL"
    }

    private fun computeEma(values: List<Double>, period: Int): List<Double?> {
        val out = MutableList<Double?>(values.size) { null }
        if (values.size < period) return out
        var ema = values.take(period).average()
        out[period - 1] = ema
        val k = 2.0 / (period + 1)
        for (i in period until values.size) {
            ema = values[i] * k + ema * (1 - k)
            out[i] = ema
        }
        return out
    }

    private fun computeWilderRsi(closes: List<Double>, period: Int): List<Double?> {
        val out = MutableList<Double?>(closes.size) { null }
        if (closes.size <= period) return out
        var gain = 0.0
        var loss = 0.0
        for (i in 1..period) {
            val d = closes[i] - closes[i - 1]
            if (d >= 0) gain += d else loss += abs(d)
        }
        var avgGain = gain / period
        var avgLoss = loss / period
        out[period] = if (avgLoss == 0.0) 100.0 else 100.0 - 100.0 / (1.0 + avgGain / avgLoss)
        for (i in period + 1 until closes.size) {
            val d = closes[i] - closes[i - 1]
            avgGain = (avgGain * (period - 1) + (if (d > 0) d else 0.0)) / period
            avgLoss = (avgLoss * (period - 1) + (if (d < 0) abs(d) else 0.0)) / period
            out[i] = if (avgLoss == 0.0) 100.0 else 100.0 - 100.0 / (1.0 + avgGain / avgLoss)
        }
        return out
    }

    private fun computeMacd(closes: List<Double>): Triple<List<Double?>, List<Double?>, List<Double?>> {
        val fast = computeEma(closes, 12)
        val slow = computeEma(closes, 26)
        val macd = closes.indices.map { i ->
            if (fast[i] != null && slow[i] != null) fast[i]!! - slow[i]!! else null
        }
        val firstValid = macd.indexOfFirst { it != null }
        val signal = MutableList<Double?>(closes.size) { null }
        val hist = MutableList<Double?>(closes.size) { null }
        if (firstValid != -1) {
            val sigSlice = computeEma(macd.subList(firstValid, macd.size).map { it!! }, 9)
            for (i in sigSlice.indices) {
                val idx = firstValid + i
                signal[idx] = sigSlice[i]
                if (macd[idx] != null && signal[idx] != null) hist[idx] = macd[idx]!! - signal[idx]!!
            }
        }
        return Triple(macd, signal, hist)
    }

    private fun computeAtr(candles: List<Candle>, period: Int): List<Double?> {
        val out = MutableList<Double?>(candles.size) { null }
        if (candles.size <= period) return out
        val tr = mutableListOf(candles[0].high - candles[0].low)
        for (i in 1 until candles.size) {
            val c = candles[i]
            val pc = candles[i - 1].close
            tr += max(c.high - c.low, max(abs(c.high - pc), abs(c.low - pc)))
        }
        var atr = tr.subList(1, period + 1).average()
        out[period] = atr
        for (i in period + 1 until candles.size) {
            atr = (atr * (period - 1) + tr[i]) / period
            out[i] = atr
        }
        return out
    }
}
