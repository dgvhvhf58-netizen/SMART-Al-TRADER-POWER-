package com.smartaitrader.power.data.model

enum class Timeframe(val label: String, val durationMs: Long) {
    M1("1m", 60_000L),
    M2("2m", 120_000L),
    M3("3m", 180_000L),
    M5("5m", 300_000L),
    M10("10m", 600_000L),
    M15("15m", 900_000L)
}

enum class SignalDirection(val displayLabel: String) {
    UP("UP / BUY"),
    DOWN("DOWN / SELL"),
    NO_TRADE("NO TRADE"),
    DATA_UNAVAILABLE("DATA UNAVAILABLE")
}

enum class RiskLevel { LOW, MODERATE, HIGH, EXTREME }

data class Candle(
    val time: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
)

data class FactorResult(
    val id: Int,
    val name: String,
    val valueText: String,
    val bias: String,
    val weight: Int,
    val explanation: String
)

data class SignalEvaluation(
    val assetId: String,
    val timeframe: Timeframe,
    val direction: SignalDirection,
    val confidence: Int,
    val riskLevel: RiskLevel,
    val entryPrice: Double?,
    val buyerPressurePct: Int,
    val sellerPressurePct: Int,
    val rsi14: Double?,
    val ema20: Double?,
    val ema50: Double?,
    val ema200: Double?,
    val atr14: Double?,
    val marketStructure: String,
    val trendDirection: String,
    val reasons: List<String>,
    val factors: List<FactorResult>,
    val evaluatedAt: Long = System.currentTimeMillis()
)

sealed interface MarketFeedResult {
    data class Available(
        val assetId: String,
        val sourceName: String,
        val providerSymbol: String,
        val freshnessStatus: String,
        val lastCandleTimeMs: Long,
        val isQuotexOtc: Boolean,
        val candles: List<Candle>
    ) : MarketFeedResult

    data class Unavailable(
        val assetId: String,
        val reason: String
    ) : MarketFeedResult
}
