package com.smartaitrader.power.data.remote

import com.smartaitrader.power.data.model.Candle
import com.smartaitrader.power.data.model.MarketFeedResult
import com.smartaitrader.power.data.model.Timeframe
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class QuotexMarketRepository(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()
) {
    /**
     * Strict Quotex OTC Policy:
     * Quotex does not provide a public official API for proprietary OTC synthetic pairs.
     * Unless the user supplies an authorized Quotex OTC Bridge URL, this repository
     * MUST return Unavailable (DATA UNAVAILABLE) and NEVER substitute another broker's feed.
     */
    suspend fun fetchCandles(
        assetId: String,
        timeframe: Timeframe,
        authorizedBridgeUrl: String?
    ): MarketFeedResult = withContext(Dispatchers.IO) {
        val isOtc = assetId.endsWith("-OTC")

        if (isOtc) {
            val cleanBridge = authorizedBridgeUrl?.trim().orEmpty()
            if (cleanBridge.isEmpty()) {
                return@withContext MarketFeedResult.Unavailable(
                    assetId = assetId,
                    reason = "DATA UNAVAILABLE: Quotex OTC has no public official API. Configure your authorized Quotex OTC Bridge URL to stream verified OTC candles."
                )
            }
            return@withContext fetchFromAuthorizedBridge(cleanBridge, assetId, timeframe)
        }

        if (assetId.endsWith("-SPOT")) {
            return@withContext fetchPublicSpotExchangeCandles(assetId, timeframe)
        }

        // Forex (-FX), Stocks (-EQ), Indices (-IDX), Commodities (-CMD) via Yahoo Finance v8 Chart API
        return@withContext fetchYahooChartCandles(assetId, timeframe)
    }

    private fun fetchFromAuthorizedBridge(
        bridgeUrl: String,
        assetId: String,
        timeframe: Timeframe
    ): MarketFeedResult {
        return try {
            val separator = if (bridgeUrl.contains("?")) "&" else "?"
            val url = "$bridgeUrl${separator}asset=$assetId&timeframe=${timeframe.label}"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    return MarketFeedResult.Unavailable(assetId, "Bridge HTTP ${resp.code}")
                }
                val body = resp.body?.string().orEmpty()
                val json = JSONObject(body)
                val arr = json.optJSONArray("candles") ?: return MarketFeedResult.Unavailable(
                    assetId,
                    "Bridge returned no candles array"
                )
                val candles = parseBridgeCandles(arr)
                if (candles.isEmpty()) {
                    MarketFeedResult.Unavailable(assetId, "Bridge returned 0 verified candles")
                } else {
                    val lastTs = candles.last().time
                    MarketFeedResult.Available(assetId, "Authorized Quotex OTC Bridge", assetId, computeFreshness(lastTs, timeframe), lastTs, true, candles)
                }
            }
        } catch (e: Exception) {
            MarketFeedResult.Unavailable(assetId, "Bridge connection failed: ${e.message}")
        }
    }

    private fun fetchPublicSpotExchangeCandles(
        assetId: String,
        timeframe: Timeframe
    ): MarketFeedResult {
        val symbol = assetId.replace("-SPOT", "")
        val fetchInterval = when (timeframe) {
            Timeframe.M2, Timeframe.M10 -> "1m"
            else -> timeframe.label
        }
        val limit = if (timeframe == Timeframe.M2 || timeframe == Timeframe.M10) 600 else 220

        val hosts = listOf("https://api.binance.com", "https://data-api.binance.vision")
        var lastError = "Unable to connect"
        for (host in hosts) {
            try {
                val url = "$host/api/v3/klines?symbol=$symbol&interval=$fetchInterval&limit=$limit"
                val req = Request.Builder().url(url).get().build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) {
                        lastError = "Spot feed HTTP ${resp.code}"
                        return@use
                    }
                    val arr = JSONArray(resp.body?.string().orEmpty())
                    val raw = mutableListOf<Candle>()
                    for (i in 0 until arr.length()) {
                        val row = arr.getJSONArray(i)
                        raw.add(
                            Candle(
                                time = row.getLong(0),
                                open = row.getString(1).toDouble(),
                                high = row.getString(2).toDouble(),
                                low = row.getString(3).toDouble(),
                                close = row.getString(4).toDouble(),
                                volume = row.getString(5).toDouble()
                            )
                        )
                    }
                    val finalCandles = when (timeframe) {
                        Timeframe.M2 -> aggregateCandles(raw, 2)
                        Timeframe.M10 -> aggregateCandles(raw, 10)
                        else -> raw
                    }
                    val lastTs = finalCandles.lastOrNull()?.time ?: 0L
                    return MarketFeedResult.Available(
                        assetId = assetId,
                        sourceName = if (host.contains("vision")) "Binance Spot Vision Mirror (Not Quotex OTC)" else "Binance Public Spot (Not Quotex OTC)",
                        providerSymbol = symbol,
                        freshnessStatus = computeFreshness(lastTs, timeframe),
                        lastCandleTimeMs = lastTs,
                        isQuotexOtc = false,
                        candles = finalCandles
                    )
                }
            } catch (e: Exception) {
                lastError = e.message ?: "Network error"
            }
        }
        return MarketFeedResult.Unavailable(assetId, "Spot network unavailable: $lastError")
    }

    private fun fetchYahooChartCandles(
        assetId: String,
        timeframe: Timeframe
    ): MarketFeedResult {
        val yahooSymbol = when (assetId) {
            "EURUSD-FX" -> "EURUSD=X"
            "GBPUSD-FX" -> "GBPUSD=X"
            "USDJPY-FX" -> "USDJPY=X"
            "AUDUSD-FX" -> "AUDUSD=X"
            "AAPL-EQ" -> "AAPL"
            "NVDA-EQ" -> "NVDA"
            "TSLA-EQ" -> "TSLA"
            "MSFT-EQ" -> "MSFT"
            "SPX-IDX" -> "^GSPC"
            "IXIC-IDX" -> "^IXIC"
            "DJI-IDX" -> "^DJI"
            "NIFTY-IDX" -> "^NSEI"
            "XAUUSD-CMD" -> "GC=F"
            "XAGUSD-CMD" -> "SI=F"
            "WTI-CMD" -> "CL=F"
            else -> assetId
        }
        val (interval, range, aggFactor) = when (timeframe) {
            Timeframe.M1 -> Triple("1m", "1d", 1)
            Timeframe.M2 -> Triple("1m", "1d", 2)
            Timeframe.M3 -> Triple("1m", "1d", 3)
            Timeframe.M5 -> Triple("5m", "5d", 1)
            Timeframe.M10 -> Triple("5m", "5d", 2)
            Timeframe.M15 -> Triple("15m", "1mo", 1)
        }
        return try {
            val url = "https://query1.finance.yahoo.com/v8/finance/chart/$yahooSymbol?interval=$interval&range=$range&includePrePost=false"
            val req = Request.Builder().url(url).header("User-Agent", "Mozilla/5.0").get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    return MarketFeedResult.Unavailable(assetId, "Yahoo Finance HTTP ${resp.code}")
                }
                val root = JSONObject(resp.body?.string().orEmpty())
                val result = root.getJSONObject("chart").getJSONArray("result").getJSONObject(0)
                val meta = result.getJSONObject("meta")
                val exchange = meta.optString("fullExchangeName", "Yahoo Finance")
                val tsArr = result.getJSONArray("timestamp")
                val quote = result.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0)
                val opens = quote.getJSONArray("open")
                val highs = quote.getJSONArray("high")
                val lows = quote.getJSONArray("low")
                val closes = quote.getJSONArray("close")
                val vols = quote.optJSONArray("volume")
                val raw = mutableListOf<Candle>()
                for (i in 0 until tsArr.length()) {
                    if (opens.isNull(i) || closes.isNull(i)) continue
                    raw.add(
                        Candle(
                            time = tsArr.getLong(i) * 1000L,
                            open = opens.getDouble(i),
                            high = highs.getDouble(i),
                            low = lows.getDouble(i),
                            close = closes.getDouble(i),
                            volume = if (vols != null && !vols.isNull(i)) vols.getDouble(i) else 0.0
                        )
                    )
                }
                if (raw.isEmpty()) return MarketFeedResult.Unavailable(assetId, "Empty OHLCV series from $exchange")
                val finalCandles = if (aggFactor > 1) aggregateCandles(raw, aggFactor) else raw
                val lastTs = finalCandles.last().time
                MarketFeedResult.Available(
                    assetId = assetId,
                    sourceName = "Yahoo Finance ($exchange)",
                    providerSymbol = yahooSymbol,
                    freshnessStatus = computeFreshness(lastTs, timeframe),
                    lastCandleTimeMs = lastTs,
                    isQuotexOtc = false,
                    candles = finalCandles
                )
            }
        } catch (e: Exception) {
            MarketFeedResult.Unavailable(assetId, "Feed unreachable: ${e.message}")
        }
    }

    private fun computeFreshness(lastCandleTimeMs: Long, timeframe: Timeframe): String {
        val ageSec = ((System.currentTimeMillis() - lastCandleTimeMs) / 1000L).coerceAtLeast(0L)
        val liveThreshold = maxOf(180L, (timeframe.durationMs / 1000L) * 2L + 60L)
        return when {
            ageSec > 1800L -> "MARKET_CLOSED"
            ageSec > liveThreshold -> "DELAYED"
            else -> "LIVE"
        }
    }

    private fun aggregateCandles(source: List<Candle>, factor: Int): List<Candle> {
        val bucketMs = factor * 60_000L
        return source.groupBy { (it.time / bucketMs) * bucketMs }
            .toSortedMap()
            .values
            .map { group ->
                Candle(
                    time = (group.first().time / bucketMs) * bucketMs,
                    open = group.first().open,
                    high = group.maxOf { it.high },
                    low = group.minOf { it.low },
                    close = group.last().close,
                    volume = group.sumOf { it.volume }
                )
            }
    }

    private fun parseBridgeCandles(arr: JSONArray): List<Candle> {
        val list = mutableListOf<Candle>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                Candle(
                    time = o.getLong("time"),
                    open = o.getDouble("open"),
                    high = o.getDouble("high"),
                    low = o.getDouble("low"),
                    close = o.getDouble("close"),
                    volume = o.optDouble("volume", 0.0)
                )
            )
        }
        return list
    }
}
