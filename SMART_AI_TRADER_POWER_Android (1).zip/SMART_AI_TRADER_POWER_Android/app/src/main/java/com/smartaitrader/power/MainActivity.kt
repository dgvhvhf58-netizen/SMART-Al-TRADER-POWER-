package com.smartaitrader.power

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.smartaitrader.power.data.model.SignalDirection
import com.smartaitrader.power.data.model.Timeframe
import com.smartaitrader.power.service.FloatingSignalService
import com.smartaitrader.power.ui.viewmodel.DashboardViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: DashboardViewModel by viewModels()

    private var pendingAssetId: String = "BTCUSDT-SPOT"
    private var pendingTfLabel: String = Timeframe.M1.label
    private var pendingBridgeUrl: String = ""

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    // Automatically start floating overlay once user returns after granting SYSTEM_ALERT_WINDOW
    private val overlayPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (Settings.canDrawOverlays(this)) {
                launchFloatingForegroundService(pendingAssetId, pendingTfLabel, pendingBridgeUrl, openBoard = true)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        val marketAssets = listOf(
            "EURUSD-OTC",
            "GBPUSD-OTC",
            "BTCUSDT-SPOT",
            "ETHUSDT-SPOT",
            "EURUSD-FX",
            "AAPL-EQ",
            "XAUUSD-CMD"
        )

        setContent {
            val state by viewModel.uiState.collectAsState()
            val stats by viewModel.verifiedStats.collectAsState()
            val history by viewModel.history.collectAsState()
            val isFloating by FloatingSignalService.isServiceRunning.collectAsState()
            val isWindowOpen by FloatingSignalService.isWindowVisible.collectAsState()

            LaunchedEffect(state.selectedAssetId, state.selectedTimeframe, state.bridgeUrl, isFloating) {
                if (isFloating) {
                    syncFloatingConfig(state.selectedAssetId, state.selectedTimeframe.label, state.bridgeUrl)
                }
            }

            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Color(0xFF070B12),
                    surface = Color(0xFF0D1420),
                    primary = Color(0xFF10B981),
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF070B12)) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "SMART AI TRADER POWER",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Source: ${state.sourceLabel}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF94A3B8)
                        )

                        // Asset Selector Row
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            marketAssets.forEach { asset ->
                                FilterChip(
                                    selected = state.selectedAssetId == asset,
                                    onClick = { viewModel.selectAsset(asset) },
                                    label = { Text(asset) }
                                )
                            }
                        }

                        // 6-Timeframe Selector
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Timeframe.entries.forEach { tf ->
                                FilterChip(
                                    selected = state.selectedTimeframe == tf,
                                    onClick = { viewModel.selectTimeframe(tf) },
                                    label = { Text(tf.label) }
                                )
                            }
                        }

                        // Primary Signal Card
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1420))) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                val dir = state.evaluation?.direction ?: SignalDirection.DATA_UNAVAILABLE
                                Text(
                                    text = state.unavailableReason?.let { "DATA UNAVAILABLE" } ?: dir.displayLabel,
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = when (dir) {
                                        SignalDirection.UP -> Color(0xFF10B981)
                                        SignalDirection.DOWN -> Color(0xFFEF4444)
                                        else -> Color(0xFFF59E0B)
                                    }
                                )
                                val priceText = state.evaluation?.entryPrice?.let { String.format("%.4f", it) } ?: "--"
                                Text(
                                    text = state.unavailableReason
                                        ?: "Entry: $priceText · Conf: ${state.evaluation?.confidence ?: 0}% · Risk: ${state.evaluation?.riskLevel ?: "HIGH"}",
                                    color = Color(0xFFCBD5E1)
                                )
                            }
                        }

                        Button(
                            onClick = { viewModel.analyzeNow(persistRecord = true) },
                            modifier = Modifier.fillMaxWidth().height(52.dp)
                        ) {
                            Text("AI ANALYZE NOW")
                        }

                        // Unified Verified Accuracy Database Summary (Matches Signal History)
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1420))) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "Verified Accuracy: ${stats.summaryText}",
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White
                                )
                                Text(
                                    text = "Wins: ${stats.wins} · Losses: ${stats.losses} · Pending: ${stats.pending} · NO TRADE: ${stats.noTrade}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                        }

                        // Floating Overlay Controls
                        Text(
                            text = "Floating Service Status: ${if (isFloating) (if (isWindowOpen) "ACTIVE (BOARD OPEN)" else "ACTIVE OVER APPS") else "STOPPED"}",
                            color = if (isFloating) Color(0xFF10B981) else Color(0xFF94A3B8)
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = { startFloatingOverlay(state.selectedAssetId, state.selectedTimeframe.label, state.bridgeUrl, openBoard = true) },
                                modifier = Modifier.weight(1f)
                            ) { Text("START FLOATING") }

                            OutlinedButton(
                                onClick = {
                                    if (isFloating) sendFloatingCommand(FloatingSignalService.ACTION_STOP_FLOATING)
                                },
                                enabled = isFloating,
                                modifier = Modifier.weight(1f)
                            ) { Text("STOP FLOATING") }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(
                                onClick = {
                                    if (isFloating) sendFloatingCommand(FloatingSignalService.ACTION_CLOSE_WINDOW)
                                },
                                enabled = isFloating && isWindowOpen,
                                modifier = Modifier.weight(1f)
                            ) { Text("CLOSE WINDOW") }

                            OutlinedButton(
                                onClick = {
                                    if (isFloating) {
                                        sendFloatingCommand(FloatingSignalService.ACTION_REOPEN_WINDOW)
                                    } else {
                                        startFloatingOverlay(state.selectedAssetId, state.selectedTimeframe.label, state.bridgeUrl, openBoard = true)
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            ) { Text("REOPEN WINDOW") }
                        }

                        // Recent Signal Database Records
                        if (history.isNotEmpty()) {
                            Text(
                                text = "Recent Signals (${history.size})",
                                style = MaterialTheme.typography.titleSmall,
                                color = Color(0xFFCBD5E1)
                            )
                            history.take(5).forEach { rec ->
                                Text(
                                    text = "${rec.assetId} (${rec.timeframe}) · ${rec.direction} · ${rec.result} @ ${String.format("%.4f", rec.entryPrice)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    private fun startFloatingOverlay(assetId: String, tf: String, bridgeUrl: String, openBoard: Boolean) {
        pendingAssetId = assetId
        pendingTfLabel = tf
        pendingBridgeUrl = bridgeUrl
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
            return
        }
        launchFloatingForegroundService(assetId, tf, bridgeUrl, openBoard)
    }

    private fun launchFloatingForegroundService(assetId: String, tf: String, bridgeUrl: String, openBoard: Boolean) {
        val svc = Intent(this, FloatingSignalService::class.java).apply {
            action = FloatingSignalService.ACTION_START_FLOATING
            putExtra(FloatingSignalService.EXTRA_ASSET_ID, assetId)
            putExtra(FloatingSignalService.EXTRA_TIMEFRAME, tf)
            putExtra(FloatingSignalService.EXTRA_BRIDGE_URL, bridgeUrl)
            putExtra(FloatingSignalService.EXTRA_OPEN_BOARD, openBoard)
        }
        ContextCompat.startForegroundService(this, svc)
    }

    private fun syncFloatingConfig(assetId: String, tf: String, bridgeUrl: String) {
        val svc = Intent(this, FloatingSignalService::class.java).apply {
            action = FloatingSignalService.ACTION_UPDATE_CONFIG
            putExtra(FloatingSignalService.EXTRA_ASSET_ID, assetId)
            putExtra(FloatingSignalService.EXTRA_TIMEFRAME, tf)
            putExtra(FloatingSignalService.EXTRA_BRIDGE_URL, bridgeUrl)
        }
        ContextCompat.startForegroundService(this, svc)
    }

    private fun sendFloatingCommand(actionName: String) {
        val svc = Intent(this, FloatingSignalService::class.java).apply {
            action = actionName
        }
        if (actionName == FloatingSignalService.ACTION_REOPEN_WINDOW) {
            ContextCompat.startForegroundService(this, svc)
        } else {
            startService(svc)
        }
    }
}
