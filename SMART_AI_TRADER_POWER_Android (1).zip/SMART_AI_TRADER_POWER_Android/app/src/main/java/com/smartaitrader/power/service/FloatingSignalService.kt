package com.smartaitrader.power.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.smartaitrader.power.MainActivity
import com.smartaitrader.power.data.local.SignalDatabase
import com.smartaitrader.power.data.local.SignalHistoryEntity
import com.smartaitrader.power.data.model.MarketFeedResult
import com.smartaitrader.power.data.model.SignalDirection
import com.smartaitrader.power.data.model.SignalEvaluation
import com.smartaitrader.power.data.model.Timeframe
import com.smartaitrader.power.data.remote.QuotexMarketRepository
import com.smartaitrader.power.domain.engine.SignalEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID
import kotlin.math.abs

class FloatingSignalService : Service() {

    companion object {
        const val ACTION_START_FLOATING = "com.smartaitrader.power.START_FLOATING"
        const val ACTION_STOP_FLOATING = "com.smartaitrader.power.STOP_FLOATING"
        const val ACTION_CLOSE_WINDOW = "com.smartaitrader.power.CLOSE_WINDOW"
        const val ACTION_REOPEN_WINDOW = "com.smartaitrader.power.REOPEN_WINDOW"
        const val ACTION_UPDATE_CONFIG = "com.smartaitrader.power.UPDATE_CONFIG"

        const val EXTRA_ASSET_ID = "extra_asset_id"
        const val EXTRA_TIMEFRAME = "extra_timeframe"
        const val EXTRA_BRIDGE_URL = "extra_bridge_url"
        const val EXTRA_OPEN_BOARD = "extra_open_board"

        private const val CHANNEL_ID = "smart_ai_floating_channel"
        private const val NOTIFICATION_ID = 7001

        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning: StateFlow<Boolean> = _isServiceRunning

        private val _isWindowVisible = MutableStateFlow(false)
        val isWindowVisible: StateFlow<Boolean> = _isWindowVisible

        private val _latestEvaluation = MutableStateFlow<SignalEvaluation?>(null)
        val latestEvaluation: StateFlow<SignalEvaluation?> = _latestEvaluation
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val repository = QuotexMarketRepository()
    private val dao by lazy { SignalDatabase.getInstance(applicationContext).signalDao() }

    private lateinit var windowManager: WindowManager
    private var rootBubbleView: View? = null
    private var signalBoardLayout: LinearLayout? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private var autoRefreshJob: Job? = null
    @Volatile
    private var isForegroundStarted = false

    private var currentAssetId = "BTCUSDT-SPOT"
    private var currentTimeframe = Timeframe.M1
    private var authorizedBridgeUrl: String? = null

    private var titleText: TextView? = null
    private var signalText: TextView? = null
    private var metaText: TextView? = null
    private var reasonText: TextView? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    private fun ensureForegroundStarted() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        isForegroundStarted = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action

        // Safe stop: promote briefly if needed, cancel coroutines, remove overlay, clear notification, stopSelf
        if (action == ACTION_STOP_FLOATING) {
            if (!isForegroundStarted) {
                runCatching { ensureForegroundStarted() }
            }
            stopOverlaySafely()
            return START_NOT_STICKY
        }

        // Apply updated config extras when supplied
        intent?.getStringExtra(EXTRA_ASSET_ID)?.let { if (it.isNotBlank()) currentAssetId = it }
        intent?.getStringExtra(EXTRA_TIMEFRAME)?.let { tfStr ->
            currentTimeframe = Timeframe.entries.firstOrNull { it.label == tfStr } ?: currentTimeframe
        }
        if (intent?.hasExtra(EXTRA_BRIDGE_URL) == true) {
            authorizedBridgeUrl = intent.getStringExtra(EXTRA_BRIDGE_URL)
        }

        // Mandatory foreground call before Android 5s timeout for all non-stop starts
        ensureForegroundStarted()
        _isServiceRunning.value = true

        // Overlay permission guard prevents WindowManager.BadTokenException
        if (!Settings.canDrawOverlays(this)) {
            stopOverlaySafely()
            return START_NOT_STICKY
        }

        when (action) {
            ACTION_CLOSE_WINDOW -> {
                signalBoardLayout?.visibility = View.GONE
                _isWindowVisible.value = false
                stopAutoRefreshLoop()
            }
            ACTION_REOPEN_WINDOW -> {
                if (ensureOverlayAttached()) {
                    signalBoardLayout?.visibility = View.VISIBLE
                    _isWindowVisible.value = true
                    refreshSignalInOverlay(persistRecord = false)
                    startAutoRefreshLoop()
                }
            }
            ACTION_UPDATE_CONFIG -> {
                if (ensureOverlayAttached()) {
                    updateNotificationText()
                    refreshSignalInOverlay(persistRecord = false)
                }
            }
            else -> {
                val openBoard = intent?.getBooleanExtra(EXTRA_OPEN_BOARD, true) ?: true
                if (ensureOverlayAttached()) {
                    signalBoardLayout?.visibility = if (openBoard) View.VISIBLE else View.GONE
                    _isWindowVisible.value = openBoard
                    if (openBoard) {
                        refreshSignalInOverlay(persistRecord = false)
                        startAutoRefreshLoop()
                    }
                }
            }
        }
        return START_STICKY
    }

    private fun stopOverlaySafely() {
        stopAutoRefreshLoop()
        removeOverlay()
        _isServiceRunning.value = false
        _isWindowVisible.value = false
        isForegroundStarted = false
        runCatching { ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE) }
        stopSelf()
    }

    private fun startAutoRefreshLoop() {
        autoRefreshJob?.cancel()
        autoRefreshJob = serviceScope.launch {
            while (isActive && _isServiceRunning.value && _isWindowVisible.value) {
                delay(12_000L)
                if (_isServiceRunning.value && _isWindowVisible.value) {
                    refreshSignalInOverlay(persistRecord = false)
                }
            }
        }
    }

    private fun stopAutoRefreshLoop() {
        autoRefreshJob?.cancel()
        autoRefreshJob = null
    }

    private fun ensureOverlayAttached(): Boolean {
        if (rootBubbleView != null) return true
        if (!Settings.canDrawOverlays(this)) return false

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
        }

        // Draggable Floating AI Logo Button
        val logoButton = TextView(this).apply {
            text = "AI"
            setTextColor(Color.parseColor("#10B981"))
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(28, 22, 28, 22)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#0D1420"))
                setStroke(3, Color.parseColor("#10B981"))
            }
        }

        // Expandable Floating Signal Board
        val board = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(28, 24, 28, 24)
            background = GradientDrawable().apply {
                cornerRadius = 28f
                setColor(Color.parseColor("#EC070B12"))
                setStroke(2, Color.parseColor("#334155"))
            }
        }

        val tTitle = TextView(this).apply {
            text = "$currentAssetId · ${currentTimeframe.label}"
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 12f
        }
        val tSignal = TextView(this).apply {
            text = "TAP ANALYZE"
            setTextColor(Color.WHITE)
            textSize = 18f
            setPadding(0, 8, 0, 6)
        }
        val tMeta = TextView(this).apply {
            text = "Confidence: -- · Risk: --"
            setTextColor(Color.parseColor("#CBD5E1"))
            textSize = 12f
        }
        val tReason = TextView(this).apply {
            text = "Real-time 18-factor overlay ready"
            setTextColor(Color.parseColor("#64748B"))
            textSize = 11f
            setPadding(0, 4, 0, 10)
        }

        val analyzeBtn = Button(this).apply {
            text = "AI ANALYZE NOW"
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.parseColor("#10B981"))
            setOnClickListener { refreshSignalInOverlay(persistRecord = true) }
        }

        val hideBtn = Button(this).apply {
            text = "CLOSE WINDOW"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#1E293B"))
            setOnClickListener {
                board.visibility = View.GONE
                _isWindowVisible.value = false
                stopAutoRefreshLoop()
            }
        }

        val stopBtn = Button(this).apply {
            text = "STOP SERVICE"
            setTextColor(Color.parseColor("#FCA5A5"))
            setBackgroundColor(Color.parseColor("#2A1215"))
            setOnClickListener { stopOverlaySafely() }
        }

        board.addView(tTitle)
        board.addView(tSignal)
        board.addView(tMeta)
        board.addView(tReason)
        board.addView(analyzeBtn)
        board.addView(hideBtn)
        board.addView(stopBtn)

        container.addView(logoButton)
        container.addView(board)

        titleText = tTitle
        signalText = tSignal
        metaText = tMeta
        reasonText = tReason

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val displayMetrics = resources.displayMetrics
        val maxScreenX = (displayMetrics.widthPixels - 140).coerceAtLeast(100)
        val maxScreenY = (displayMetrics.heightPixels - 200).coerceAtLeast(100)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 240
        }

        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        logoButton.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    params.x = (initialX + dx).coerceIn(0, maxScreenX)
                    params.y = (initialY + dy).coerceIn(0, maxScreenY)
                    if (container.isAttachedToWindow) {
                        runCatching { windowManager.updateViewLayout(container, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        val show = board.visibility != View.VISIBLE
                        board.visibility = if (show) View.VISIBLE else View.GONE
                        _isWindowVisible.value = show
                        if (show) {
                            refreshSignalInOverlay(persistRecord = false)
                            startAutoRefreshLoop()
                        } else {
                            stopAutoRefreshLoop()
                        }
                    } else if (board.visibility != View.VISIBLE && container.isAttachedToWindow) {
                        // Snap floating AI bubble to nearest horizontal screen edge
                        params.x = if (params.x < maxScreenX / 2) 16 else maxScreenX - 16
                        runCatching { windowManager.updateViewLayout(container, params) }
                    }
                    true
                }
                else -> false
            }
        }

        val added = runCatching { windowManager.addView(container, params) }.isSuccess
        if (!added) {
            stopOverlaySafely()
            return false
        }
        rootBubbleView = container
        signalBoardLayout = board
        layoutParams = params
        return true
    }

    private fun refreshSignalInOverlay(persistRecord: Boolean) {
        val assetSnapshot = currentAssetId
        val tfSnapshot = currentTimeframe
        titleText?.text = "$assetSnapshot · ${tfSnapshot.label}"
        signalText?.text = "ANALYZING..."
        signalText?.setTextColor(Color.parseColor("#38BDF8"))

        serviceScope.launch {
            val feed = withContext(Dispatchers.IO) {
                repository.fetchCandles(assetSnapshot, tfSnapshot, authorizedBridgeUrl)
            }
            when (feed) {
                is MarketFeedResult.Unavailable -> {
                    signalText?.text = "DATA UNAVAILABLE"
                    signalText?.setTextColor(Color.parseColor("#F59E0B"))
                    metaText?.text = "Quotex OTC isolated · No bridge"
                    reasonText?.text = feed.reason
                    _latestEvaluation.value = null
                }
                is MarketFeedResult.Available -> {
                    val eval = SignalEngine.evaluate(feed.candles, assetSnapshot, tfSnapshot)
                    _latestEvaluation.value = eval
                    val priceLabel = eval.entryPrice?.let { String.format("%.4f", it) } ?: "--"
                    titleText?.text = "$assetSnapshot (${tfSnapshot.label}) · $priceLabel"
                    signalText?.text = eval.direction.displayLabel
                    signalText?.setTextColor(
                        when (eval.direction) {
                            SignalDirection.UP -> Color.parseColor("#10B981")
                            SignalDirection.DOWN -> Color.parseColor("#EF4444")
                            else -> Color.parseColor("#F59E0B")
                        }
                    )
                    metaText?.text = "Conf: ${eval.confidence}% · Risk: ${eval.riskLevel}"
                    reasonText?.text = eval.reasons.firstOrNull() ?: feed.sourceName

                    withContext(Dispatchers.IO) {
                        resolveExpiredSignals(assetSnapshot, tfSnapshot, feed.candles)
                        if (persistRecord && eval.direction != SignalDirection.DATA_UNAVAILABLE && eval.entryPrice != null) {
                            val isDir = eval.direction == SignalDirection.UP || eval.direction == SignalDirection.DOWN
                            dao.insertSignal(
                                SignalHistoryEntity(
                                    id = UUID.randomUUID().toString(),
                                    timestamp = eval.evaluatedAt,
                                    expiryTimestamp = eval.evaluatedAt + tfSnapshot.durationMs,
                                    assetId = eval.assetId,
                                    marketSource = feed.sourceName,
                                    timeframe = tfSnapshot.label,
                                    direction = eval.direction.displayLabel,
                                    confidence = eval.confidence,
                                    riskLevel = eval.riskLevel.name,
                                    entryPrice = eval.entryPrice,
                                    exitPrice = null,
                                    result = if (isDir) "PENDING" else "NO_TRADE",
                                    reasonsSummary = eval.reasons.joinToString(" | ")
                                )
                            )
                        }
                    }
                }
            }
        }
    }

    private suspend fun resolveExpiredSignals(
        assetId: String,
        tf: Timeframe,
        candles: List<com.smartaitrader.power.data.model.Candle>
    ) {
        if (candles.isEmpty()) return
        val pending = dao.getPendingForAsset(assetId, tf.label)
        val now = System.currentTimeMillis()
        for (rec in pending) {
            if (now < rec.expiryTimestamp) continue
            val expiryCandle = candles.firstOrNull {
                val closeTime = it.time + tf.durationMs
                closeTime >= rec.expiryTimestamp && now >= closeTime
            } ?: candles.lastOrNull()?.takeIf { it.time >= rec.expiryTimestamp } ?: continue
            val won = if (rec.direction == SignalDirection.UP.displayLabel) {
                expiryCandle.close > rec.entryPrice
            } else {
                expiryCandle.close < rec.entryPrice
            }
            dao.resolveSignal(rec.id, expiryCandle.close, if (won) "WIN" else "LOSS")
        }
    }

    private fun removeOverlay() {
        rootBubbleView?.let { view ->
            runCatching {
                if (view.isAttachedToWindow) {
                    windowManager.removeViewImmediate(view)
                }
            }
        }
        rootBubbleView = null
        signalBoardLayout = null
        layoutParams = null
    }

    private fun updateNotificationText() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SMART AI TRADER POWER")
            .setContentText("Floating AI Signal Overlay Active ($currentAssetId · ${currentTimeframe.label})")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Floating AI Overlay Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        stopAutoRefreshLoop()
        removeOverlay()
        _isServiceRunning.value = false
        _isWindowVisible.value = false
        isForegroundStarted = false
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
